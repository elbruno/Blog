﻿using System.Threading.Tasks;
using AlexaSkillsKit.Speechlet;
using AlexaSkillsKit.UI;

namespace $safeprojectname$.Alexa
{
    public class AlexaResponseAsync : SpeechletAsync
    {
        public override Task<SpeechletResponse> OnLaunchAsync(LaunchRequest launchRequest, Session session)
        {
            return Task.FromResult(CompileResponse("On Launch"));
        }

        public async override Task<SpeechletResponse> OnIntentAsync(IntentRequest intentRequest, Session session)
        {
            SpeechletResponse response = CompileResponse("On Intent");
            return await Task.FromResult(response);
        }

        public override Task OnSessionStartedAsync(SessionStartedRequest sessionStartedRequest, Session session)
        {
            return Task.FromResult(0);
        }

        public override Task OnSessionEndedAsync(SessionEndedRequest sessionEndedRequest, Session session)
        {
            return Task.FromResult(0);
        }

        public static SpeechletResponse CompileResponse(string output)
        {
            var response = new SpeechletResponse
            {
                OutputSpeech = new PlainTextOutputSpeech { Text = output },
                ShouldEndSession = true
            };
            return response;
        }
    }
}