﻿using System.Net.Http;
using System.Web.Http;
using System.Threading.Tasks;
using $safeprojectname$.Alexa;

namespace $safeprojectname$.Controllers
{
    public class AlexaController : ApiController
    {
        [Route("")]
        [HttpGet]
        [HttpHead]
        public IHttpActionResult Root()
        {
            return Ok("Website alive!");
        }

        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Post()
        {
            var speechlet = new AlexaResponseAsync();
            return await speechlet.GetResponseAsync(Request);
        }
    }
}
